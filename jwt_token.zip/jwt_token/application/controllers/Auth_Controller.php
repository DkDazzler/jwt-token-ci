<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_Controller extends CI_Controller {
	 
	public function index()
	{
		$jwt = new JWT();

		$data = array(
			'UserID'=>101,
			'Name'=>"test_name",
			'Email'=>"testmail.com",
		);


		echo $jwt->generate_token($data);


	}

	public function validate_user(){
	 $jwt = new JWT();	
	 $token = $this->uri->segment(3);	
	    try{
		 	print_r($jwt->validate_token($token));
		}catch(Exception $ex){
		 	echo "Invalid Signature";
		}
	}
}
